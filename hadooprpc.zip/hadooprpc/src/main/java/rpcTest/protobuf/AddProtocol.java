package rpcTest.protobuf;

/**
 * Created by mystoxlol on 2019/1/23, 9:09.
 * company: kongtrolink
 * description:
 * update record:
 */
public interface AddProtocol
{
    public int add(int para1,int para2);
}
