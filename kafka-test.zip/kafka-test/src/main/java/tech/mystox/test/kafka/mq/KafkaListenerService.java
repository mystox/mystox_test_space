package tech.mystox.test.kafka.mq;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

/**
 * Created by mystox on 2021/7/2, 10:05.
 * company:
 * description:
 * update record:
 */
@Service
public class KafkaListenerService {


//    @KafkaListener(topics = {"test.init.demoA","12313123"},groupId = "A")
    public void receiver(ConsumerRecord<String, String> record) {
        System.out.println("AAAAAAAAA"+record);
    }


    @KafkaListener(topics = "E7BD91E7BB9CE8BF90E7BBB4415050.E799BBE5BD95E6A8A1E59D97.E5BC82E5B8B8E799BBE5BD95E7BB9FE8AEA1")
    public void receiver2(ConsumerRecord<String, String> record) {
        System.out.println("BBBBBBBBB"+record);
    }
}
